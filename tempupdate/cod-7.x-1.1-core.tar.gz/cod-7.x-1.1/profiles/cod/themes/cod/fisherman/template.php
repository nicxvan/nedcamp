<?php

/**
 * @file
 * This file contains the main theme functions hooks and overrides.
 */
