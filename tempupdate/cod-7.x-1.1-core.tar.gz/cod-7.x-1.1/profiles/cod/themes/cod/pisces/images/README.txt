# Images
All image assets for the theme should be declared here and organized into sub
directories. The Compass generated images directory (see config.rb) is set to
use a sub directory within this folder to store generated images such as
sprites.
